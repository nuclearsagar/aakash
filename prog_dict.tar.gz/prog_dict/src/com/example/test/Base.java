package com.example.test;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Base extends Activity  {
	Button button1;
	Button button2;
	Button button3;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		TextView txt2 = (TextView)findViewById(R.id.textView1);
		 button1 = (Button)findViewById(R.id.button1);
		String str = getResources().getString(R.string.string);
		//txt2.setText("sagar");
		final EditText editText1 = (EditText) findViewById(R.id.editText2);
		final EditText editText2 = (EditText) findViewById(R.id.editText1);
		//final String Id=((TextView) editText1).getText().toString();
		//final String name=((TextView) editText2).getText().toString();
		//final TextView txt3 = (TextView)findViewById(R.id.textView3);
		//final TextView txt4 = (TextView)findViewById(R.id.textView4);
		button2 = (Button)findViewById(R.id.button2);
		button3 = (Button)findViewById(R.id.button3);
		
		
		button3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(Base.this , Show.class);
				//intent.putExtra("text2",editText1.getText().toString());
			    //intent.putExtra("text3" , editText2.getText().toString());//Sending values to new Activity
				startActivity(intent);
				
			}
			
		});
		
      button2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(Base.this , Save1.class);
				intent.putExtra("text2",editText1.getText().toString());
			    intent.putExtra("text3" , editText2.getText().toString());//Sending values to new Activity
				startActivity(intent);
				
			}
			
		});
		
		button1.setOnClickListener(new OnClickListener() {
			public void onClick(View arg0) {

			    Intent intent = new Intent(Base.this , Search.class);//Explicit Intent used here.
			    //intent.putExtra("text2",text1.getText().toString());//Sending values to new Activity
			    intent.putExtra("text4" , editText1.getText().toString());//Sending values to new Activity
				    startActivity(intent);  // Opening new Activity
 
			}
			
		});
		
		}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.base, menu);
		return true;
	}
	
}

