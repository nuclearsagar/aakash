package com.example.test;
 

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteStatement;
import android.content.Context;

public class Save {


	
		private static final  String DATABASE_NAME = "mydatabase.db1";
		private static final int DATABASE_VERSION = 1;
		static final String TABLE_NAME = "table1";
		private static Context context;
		static SQLiteDatabase dict;
		String a[];
		private SQLiteStatement insertStmt;
		
	    private static final String INSERT = "insert into "
			+ TABLE_NAME + " (Id,name) values (?,?)";

		public Save(Context context) {
			Save.context = context;
			OpenHelper openHelper = new OpenHelper(Save.context);
			Save.dict = openHelper.getWritableDatabase();
			this.insertStmt = Save.dict.compileStatement(INSERT);

		}
		public long insert(String Id,String name) {
			this.insertStmt.bindString(1, Id);
			this.insertStmt.bindString(2, name);
			return this.insertStmt.executeInsert();
		}

		public void deleteAll() {
			dict.delete(TABLE_NAME, null, null);
		}
		
		public List<String[]> selectAll()
		{

			List<String[]> list = new ArrayList<String[]>();
			Cursor cursor = dict.query(TABLE_NAME, new String[] { "id","name" },
					null, null, null, null, null); 

			int x=0;
			if (cursor.moveToFirst()) {
				do {
					String[] b1=new String[]{cursor.getString(0),cursor.getString(1)};

					list.add(b1);

					x=x+1;
				} while (cursor.moveToNext());
			}
			if (cursor != null && !cursor.isClosed()) {
				cursor.close();
			} 
			cursor.close();

			return list;
		}
		
		public String[] search(String word) {
			
		//Cursor c =  dict.query(TABLE_NAME  , new String[] {word} , null , null , null , null , null);
		//	String sql = "select name FROM table1  where   id =" + "'int' " ;
			//Cursor c = dict.rawQuery(  sql  , null );
			//Cursor c = dict.query(TABLE_NAME  , new String[] {} , null , null , null , null , null);
			//Cursor c = dict.query(TABLE_NAME, new String[] { "id" , "name" },
		
			//	null , new String[] {word},  null, null, null); 
		//	Cursor c = dict.query(TABLE_NAME, new String[] { "id" },
			//		"name", new String[]{word}, null, null, null);
			String b[] = new String[1];
			b[0] = "Not Found";
	Cursor c = dict.query(TABLE_NAME, new String[] {"name"}, "id = ?",new String[] {word}, null , null , null);
		
	    if(c.moveToFirst()) {
				do {
					
					a = new String[]{c.getString(0) };
					if(a[0] == null) {
						return b;
					}
				}while(c.moveToNext());
			}
			if (c != null && !c.isClosed()) {
				c.close();
			} 
			c.close();
			return a;
			
		}
	private static class OpenHelper extends SQLiteOpenHelper {
		
		OpenHelper(Context context) {   
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}
		
		@Override
		public void onCreate(SQLiteDatabase dict) {
			dict.execSQL("CREATE TABLE " + TABLE_NAME + " ( id TEXT, name TEXT)");
		}

		@Override
		public void onUpgrade(SQLiteDatabase dict, int oldVersion, int newVersion) {
			dict.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
			onCreate(dict);
		}
	}

}
