package com.example.test;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

public class Search extends Activity{
	String word;
	String editText1;
	Save p;
	String stg;
	String[] result;
	public void onCreate(Bundle savedInstanceState) {
	
	 super.onCreate(savedInstanceState);
		setContentView(R.layout.search);
		 word = getIntent().getExtras().getString("text4");
		TextView txt2 = (TextView)findViewById(R.id.textView1);
		  p = new Save(this);
	     result = p.search(word);
	      

			for (String name : result) {
				stg = name;

				
			}
			txt2.setText(stg);
	}
}	

