package com.example.test;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
public class Save1 extends Activity {
	String title;
	TextView msg;
	String id;
	Button button1;
	private Save dh; 
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.save);    
        id = getIntent().getExtras().getString("text2");
        title = getIntent().getExtras().getString("text3");
        this.dh = new Save(this);
		this.dh.insert(id , title);

                
    }

   
}
